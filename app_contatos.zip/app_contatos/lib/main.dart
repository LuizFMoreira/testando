// App de Contatos
// - Lista 5 contatos já cadastrados (sem tela de cadastro)
// - Cada item mostra imagem, nome e telefone
// - Ao clicar, abre outra tela com o nome do contato no AppBar

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    title: 'Contatos',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: Colors.indigo),
    home: TelaLista(),
  ));
}

// ====================== MODELO ======================
class Contato {
  String nome;
  String telefone;
  String imagem;

  Contato(this.nome, this.telefone, this.imagem);
}

// 5 contatos previamente cadastrados
List<Contato> contatos = [
  Contato("Ana Souza", "(11) 98765-4321", "assets/ana.png"),
  Contato("Bruno Costa", "(21) 99876-5432", "assets/bruno.png"),
  Contato("Carla Mendes", "(31) 97654-3210", "assets/carla.png"),
  Contato("Diego Rocha", "(41) 96543-2109", "assets/diego.png"),
  Contato("Elisa Ferreira", "(51) 95432-1098", "assets/elisa.png"),
];

// ====================== TELA 1: LISTA ======================
class TelaLista extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Contatos")),
      body: ListView.builder(
        itemCount: contatos.length,
        itemBuilder: (context, index) {
          Contato contato = contatos[index];
          return Card(
            child: ListTile(
              leading: CircleAvatar(
                radius: 26,
                backgroundImage: AssetImage(contato.imagem),
              ),
              title: Text(contato.nome, style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(contato.telefone),
              trailing: Icon(Icons.arrow_forward),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TelaDetalhe(contato)),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

// ====================== TELA 2: DETALHE ======================
class TelaDetalhe extends StatelessWidget {
  final Contato contato;

  TelaDetalhe(this.contato);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Nome do contato no AppBar
      appBar: AppBar(title: Text(contato.nome)),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 70,
              backgroundImage: AssetImage(contato.imagem),
            ),
            SizedBox(height: 20),
            Text(contato.nome, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.phone),
                SizedBox(width: 8),
                Text(contato.telefone, style: TextStyle(fontSize: 20)),
              ],
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text("Voltar"),
            ),
          ],
        ),
      ),
    );
  }
}
