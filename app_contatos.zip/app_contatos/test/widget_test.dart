import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:app_contatos/main.dart';

void main() {
  testWidgets('lista 5 contatos e abre o detalhe com o nome no AppBar', (tester) async {
    await tester.pumpWidget(MaterialApp(home: TelaLista()));
    expect(find.byType(ListTile), findsNWidgets(5));

    await tester.tap(find.text("Ana Souza"));
    await tester.pumpAndSettle();
    expect(find.descendant(of: find.byType(AppBar), matching: find.text("Ana Souza")), findsOneWidget);
  });
}
