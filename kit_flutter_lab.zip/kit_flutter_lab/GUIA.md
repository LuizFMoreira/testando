# Kit de peças — Laboratório de Flutter

Cobre as aulas 0 a 6 + aplicativo dinâmico com lista em memória.
Cada arquivo de `lib/pecas` e `lib/apps` é um **app completo, com o próprio `main()`**:
dá para copiar o arquivo inteiro para o `main.dart` de um projeto novo e rodar.

## Começar na hora da atividade

```
flutter create nome_do_app
cd nome_do_app
```

1. Apague tudo do `lib/main.dart`.
2. Cole o conteúdo da peça mais parecida com o enunciado (tabela abaixo).
3. `flutter run` e adapte.

Para ver todas as peças rodando aqui no kit: `flutter run` (abre um menu).
Para rodar uma só: `flutter run -t lib/pecas/p08_lista_memoria.dart`.

## O que o professor pedir → qual peça usar

| Enunciado parecido com...                                   | Peça base                          | Encaixar de...                 |
|-------------------------------------------------------------|------------------------------------|--------------------------------|
| Calculadora, IMC, média, conversor, dividir conta           | `p02_stateful_formulario`          | validação da `p04`             |
| Tela de perfil / cartão de visita / layout estático         | `p03_layout_widgets`               | tema da `p05`                  |
| Formulário de cadastro com validação, checkbox, radio       | `p04_inputs`                       | navegação da `p07`             |
| App com tema claro/escuro ou cor personalizada              | `p05_tema`                         | qualquer tela no `home`        |
| Jogo (cara ou coroa, pedra-papel-tesoura, dado)             | `p06_gestos`                       | placar já está pronto          |
| Uma tela manda para a outra + botão de voltar               | `p10_duas_telas`                   | variações A–G no fim do arquivo |
| Navegação com rotas nomeadas, retorno, substituir tela      | `p07_navegacao`                    | —                              |
| Lista de tarefas / lista simples com adicionar e remover    | `p08_lista_memoria`                | —                              |
| Lista de compras, com preço, total, busca, editar           | `p09_lista_extras`                 | —                              |
| Cadastro com lista + tela de detalhe + tela de cadastro     | `apps/app_crud_completo`           | tema da `p05`, gestos da `p06` |
| Pergunta só de Dart (classe, construtor, null safety, List) | `p01_dart_classes_null_safety`     | —                              |

## Adaptar o CRUD ao tema da prova (2 minutos)

No VS Code, `Ctrl+H` com **"Aa" (diferenciar maiúsculas) ligado**:

1. `Contato` → `Livro` (ou `Filme`, `Aluno`, `Produto`...)
2. `contato` → `livro`
3. `contatos` já vira `livros` sozinho pelo passo 2.

Depois ajuste em três lugares:

- **A classe**: os campos (`String titulo; String autor; int ano;`).
- **`TelaCadastro`**: um `TextEditingController` + um `TextFormField` por campo, e o `_salvar()`.
- **`_itemContato` e `TelaDetalhe`**: o que aparece na tela.

Campo numérico: `int.tryParse(_tAno.text) ?? 0` para guardar e `livro.ano.toString()` para mostrar.

## Receitas rápidas (o que mais se esquece)

**Lista em memória — o esqueleto**

```dart
List<Tarefa> tarefas = [];                       // dentro do State

setState(() { tarefas.add(Tarefa(texto)); });    // adicionar
setState(() { tarefas.removeAt(index); });       // remover
setState(() { tarefas[index].feita = true; });   // alterar

Expanded(                                        // obrigatório dentro de Column
  child: ListView.builder(
    itemCount: tarefas.length,
    itemBuilder: (context, index) {
      return ListTile(title: Text(tarefas[index].titulo));
    },
  ),
)
```

**Ler um campo de texto**

```dart
final _tNome = TextEditingController();
TextField(controller: _tNome)
_tNome.text          // ler
_tNome.clear();      // limpar
double.tryParse(_tPreco.text.replaceAll(",", ".")) ?? 0   // número sem quebrar
```

**Ir para outra tela levando um objeto, e voltar**

```dart
Navigator.push(context, MaterialPageRoute(builder: (context) => TelaDetalhe(tarefas[index])));
Navigator.pop(context);
```

**Tela devolve um valor**

```dart
var novo = await Navigator.push(context, MaterialPageRoute(builder: (context) => TelaCadastro()));
if (novo != null) { setState(() { lista.add(novo); }); }
// na outra tela:
Navigator.pop(context, objeto);
```

**Validar formulário**

```dart
final _formKey = GlobalKey<FormState>();
Form(key: _formKey, child: Column(children: [ TextFormField(validator: _validar) ]))
if (_formKey.currentState!.validate()) { ... }
```

**Aviso rápido e diálogo**

```dart
ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Salvo!")));
showDialog(context: context, builder: (context) => AlertDialog(title: Text("Atenção")));
```

**Imagem**: arquivo em `assets/`, e no `pubspec.yaml` (atenção à indentação, 2 espaços):

```yaml
flutter:
  uses-material-design: true
  assets:
    - assets/
```

Depois de mexer no `pubspec.yaml`: pare o app e rode de novo (hot reload não pega).

## Erros clássicos e o conserto

| Erro na tela / console                                    | Conserto                                                        |
|-----------------------------------------------------------|-----------------------------------------------------------------|
| Faixa amarela e preta, "RenderFlex overflowed"            | Envolver o `Column` do body em `SingleChildScrollView`; texto dentro de `Row` em `Expanded` |
| "Vertical viewport was given unbounded height"            | `ListView` dentro de `Column` precisa de `Expanded` em volta    |
| "RenderBox was not laid out" com `TextField` em `Row`     | `Expanded(child: TextField(...))`                               |
| Tela não atualiza ao clicar                               | Faltou `setState(() { ... })`, ou a tela é `StatelessWidget`    |
| "Navigator operation requested with a context that does not include a Navigator" | O `MaterialApp` tem que estar no `runApp`, e a tela ser uma classe separada no `home` |
| "Unable to load asset"                                    | Conferir nome/pasta no `pubspec.yaml` e reiniciar o app         |
| "Null check operator used on a null value"                | Um `!` em valor nulo: usar `??` ou testar `if (x != null)`      |
| "FormatException" ao calcular                             | Trocar `double.parse` por `double.tryParse(...) ?? 0`           |
| "setState() called after dispose" / `context` após `await`| Antes de usar: `if (!mounted) return;`                          |
| Em tela Stateful o parâmetro "não existe"                 | Dentro do `State` use `widget.parametro`                        |

## Diferenças entre o material da aula e o Flutter atual

- **Aula 4**: `headline1` e `bodyText2` **não existem mais** e dão erro de compilação.
  Use `headlineMedium`/`headlineLarge` e `bodyMedium` (a `p05` já está assim).
- **Aula 4**: o exemplo com `Provider` exige adicionar o pacote. A `p05` troca o tema
  só com `setState`, sem dependência externa.
- **Aula 3**: `groupValue`/`onChanged` no `RadioListTile` ainda funciona, mas aparece
  como "deprecated" (aviso, não erro). A `p04` usa esse jeito, igual à aula.
- **Aula 6**: `home:` junto com `initialRoute: "/"` e rota `"/"` no `routes` dá erro.
  Use um ou outro (a `p07` usa só rotas).
