// KIT DE PEÇAS - Laboratório de Flutter
// Este main é só um MENU para abrir e testar cada peça.
// Na atividade: copie o arquivo da peça inteiro para o main.dart do projeto novo
// (cada peça já tem o seu próprio main) e adapte. Veja o GUIA.md.

import 'package:flutter/material.dart';

import 'apps/app_crud_completo.dart';
import 'pecas/p01_dart_classes_null_safety.dart';
import 'pecas/p02_stateful_formulario.dart';
import 'pecas/p03_layout_widgets.dart';
import 'pecas/p04_inputs.dart';
import 'pecas/p05_tema.dart';
import 'pecas/p06_gestos.dart';
import 'pecas/p07_navegacao.dart';
import 'pecas/p08_lista_memoria.dart';
import 'pecas/p09_lista_extras.dart';
import 'pecas/p10_duas_telas.dart';

void main() {
  runApp(MaterialApp(
    title: 'Kit Flutter Lab',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: Colors.indigo),
    // Rotas usadas pela peça 07 (rotas nomeadas)
    routes: {
      "/secundaria": (context) => TelaSecundaria("vim pela rota nomeada"),
      "/sobre": (context) => TelaSobre(),
    },
    home: Menu(),
  ));
}

class Peca {
  String titulo;
  String descricao;
  Widget Function() tela;

  Peca(this.titulo, this.descricao, this.tela);
}

List<Peca> pecas = [
  Peca("01 - Dart: classes e null safety", "Aulas 0 e 2: construtores, listas, ?, !, ??, late", () => TelaDart()),
  Peca("02 - Stateful + formulário", "Aula 1: controllers, setState, cálculo (IMC)", () => TelaCalculo()),
  Peca("03 - Layout e widgets", "Aula 3: Container, Row, Column, imagem, botões", () => TelaLayout()),
  Peca("04 - Entrada de dados", "Aula 3: Form, validação, checkbox, radio, dropdown", () => TelaInputs()),
  Peca("05 - Tema", "Aula 4: claro/escuro, fromSeed, Theme.of", () => AppComTema()),
  Peca("06 - Gestos", "Aula 5: GestureDetector + jogo com Random", () => Jogo()),
  Peca("07 - Navegação", "Aula 6: push, pop, parâmetros, retorno, rotas", () => TelaPrincipal()),
  Peca("08 - Lista em memória (básico)", "ListView.builder, adicionar, remover, marcar", () => ListaTarefas()),
  Peca("09 - Lista em memória (extras)", "total, busca, ordenar, editar, Dismissible, diálogo", () => ListaCompras()),
  Peca("10 - Duas telas (enxuta)", "envia o texto para a outra tela + botão Voltar", () => PrimeiraTela()),
  Peca("APP - CRUD completo em 3 telas", "lista + cadastro/edição + detalhe", () => TelaLista()),
];

class Menu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Kit de peças Flutter")),
      body: ListView.builder(
        itemCount: pecas.length,
        itemBuilder: (context, index) {
          Peca peca = pecas[index];
          return Card(
            child: ListTile(
              title: Text(peca.titulo, style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(peca.descricao),
              trailing: Icon(Icons.arrow_forward),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => peca.tela()),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
