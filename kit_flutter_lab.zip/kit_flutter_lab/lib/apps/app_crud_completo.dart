// APP COMPLETO - CRUD em memória com 3 telas (junta as aulas 0 a 6)
//
//   TelaLista    -> ListView.builder, filtro por categoria, toque abre o detalhe
//   TelaCadastro -> Form com validação; serve para CADASTRAR e para EDITAR;
//                   devolve o objeto pronto no Navigator.pop
//   TelaDetalhe  -> recebe o objeto pelo construtor; botões Editar e Excluir
//
// COMO ADAPTAR AO TEMA DA PROVA (ver GUIA.md):
//   1. Ctrl+Shift+H no VS Code: troque "Contato" pelo nome pedido (Livro, Filme...)
//      marcando "Diferenciar maiúsculas" e depois "contato" -> "livro".
//   2. Ajuste os campos da classe e os TextFormField da TelaCadastro.
//
// Para rodar sozinho: flutter run -t lib/apps/app_crud_completo.dart

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      colorSchemeSeed: Colors.teal,
      appBarTheme: AppBarTheme(backgroundColor: Colors.teal, foregroundColor: Colors.white),
    ),
    home: TelaLista(),
  ));
}

// ====================== MODELO (Aula 0) ======================
class Contato {
  String nome;
  String telefone;
  String email;
  String categoria;
  bool favorito;

  Contato({
    required this.nome,
    required this.telefone,
    this.email = "",
    this.categoria = "Amigos",
    this.favorito = false,
  });
}

List<String> categorias = ["Amigos", "Família", "Trabalho"];

// A lista em memória. Fica fora das classes para todas as telas enxergarem.
List<Contato> contatos = [
  Contato(nome: "Ana Souza", telefone: "(31) 98765-4321", email: "ana@email.com", categoria: "Família"),
  Contato(nome: "Bruno Lima", telefone: "(31) 97654-3210", categoria: "Trabalho", favorito: true),
  Contato(nome: "Carla Dias", telefone: "(11) 96543-2109", email: "carla@email.com"),
];

// ====================== TELA 1: LISTA ======================
class TelaLista extends StatefulWidget {
  @override
  State<TelaLista> createState() => _TelaListaState();
}

class _TelaListaState extends State<TelaLista> {
  String _filtro = "Todos";

  List<Contato> _filtrados() {
    if (_filtro == "Todos") {
      return contatos;
    }
    if (_filtro == "Favoritos") {
      return contatos.where((c) => c.favorito).toList();
    }
    return contatos.where((c) => c.categoria == _filtro).toList();
  }

  // Abre o cadastro e espera o objeto novo voltar no pop
  void _novo() async {
    Contato? novo = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => TelaCadastro()),
    );
    if (novo != null) {
      setState(() {
        contatos.add(novo);
      });
    }
  }

  // Abre o detalhe; quando voltar, redesenha (pode ter editado ou excluído)
  void _abrir(Contato contato) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => TelaDetalhe(contato)),
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    List<Contato> visiveis = _filtrados();

    return Scaffold(
      appBar: AppBar(title: Text("Contatos (" + contatos.length.toString() + ")")),
      body: Column(
        children: [
          // Filtro
          Padding(
            padding: EdgeInsets.only(left: 15, right: 15, top: 5),
            child: Row(
              children: [
                Text("Mostrar: ", style: TextStyle(fontSize: 16)),
                Expanded(
                  child: DropdownButton<String>(
                    value: _filtro,
                    isExpanded: true,
                    items: (["Todos", "Favoritos"] + categorias).map((String c) {
                      return DropdownMenuItem<String>(value: c, child: Text(c));
                    }).toList(),
                    onChanged: (String? value) {
                      setState(() {
                        _filtro = value!;
                      });
                    },
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: visiveis.isEmpty
                ? Center(child: Text("Nenhum contato"))
                : ListView.builder(
                    itemCount: visiveis.length,
                    itemBuilder: (context, index) {
                      return _itemContato(visiveis[index]);
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _novo,
        child: Icon(Icons.add),
      ),
    );
  }

  // Função de reuso: um item da lista (Aula 3) com GestureDetector (Aula 5)
  Widget _itemContato(Contato contato) {
    return GestureDetector(
      onTap: () {
        _abrir(contato);
      },
      onLongPress: () {
        // segurar: favorita/desfavorita
        setState(() {
          contato.favorito = !contato.favorito;
        });
      },
      child: Container(
        padding: EdgeInsets.all(10),
        margin: EdgeInsets.only(left: 10, right: 10, top: 10),
        decoration: BoxDecoration(
          color: Colors.teal.shade50,
          border: Border.all(width: 1, color: Colors.teal),
        ),
        child: Row(
          children: [
            CircleAvatar(child: Text(contato.nome[0].toUpperCase())),
            // Com foto: Image.asset(contato.imagem, width: 60, height: 60, fit: BoxFit.cover)
            SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(contato.nome, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Text(contato.telefone + "  -  " + contato.categoria),
                ],
              ),
            ),
            Icon(
              contato.favorito ? Icons.star : Icons.star_border,
              color: Colors.orange,
            ),
          ],
        ),
      ),
    );
  }
}

// ====================== TELA 2: CADASTRO / EDIÇÃO ======================
class TelaCadastro extends StatefulWidget {
  // Se vier um contato, a tela edita. Se vier null, cadastra um novo.
  final Contato? contato;

  TelaCadastro({this.contato});

  @override
  State<TelaCadastro> createState() => _TelaCadastroState();
}

class _TelaCadastroState extends State<TelaCadastro> {
  final _formKey = GlobalKey<FormState>();
  final _tNome = TextEditingController();
  final _tTelefone = TextEditingController();
  final _tEmail = TextEditingController();
  String _categoria = categorias[0];
  bool _favorito = false;

  // initState roda uma vez quando a tela abre: preenche os campos na edição
  @override
  void initState() {
    super.initState();
    Contato? contato = widget.contato;
    if (contato != null) {
      _tNome.text = contato.nome;
      _tTelefone.text = contato.telefone;
      _tEmail.text = contato.email;
      _categoria = contato.categoria;
      _favorito = contato.favorito;
    }
  }

  String? _validarObrigatorio(String? text) {
    if (text == null || text.trim().isEmpty) {
      return "Campo obrigatório";
    }
    return null;
  }

  String? _validarEmail(String? text) {
    // opcional, mas se preencher tem que ter @
    if (text != null && text.isNotEmpty && !text.contains("@")) {
      return "E-mail inválido";
    }
    return null;
  }

  void _salvar() {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    Contato? contato = widget.contato;
    if (contato == null) {
      // Novo: devolve o objeto para a tela anterior
      Navigator.pop(
        context,
        Contato(
          nome: _tNome.text.trim(),
          telefone: _tTelefone.text.trim(),
          email: _tEmail.text.trim(),
          categoria: _categoria,
          favorito: _favorito,
        ),
      );
    } else {
      // Edição: altera o próprio objeto (é o mesmo que está na lista)
      contato.nome = _tNome.text.trim();
      contato.telefone = _tTelefone.text.trim();
      contato.email = _tEmail.text.trim();
      contato.categoria = _categoria;
      contato.favorito = _favorito;
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.contato == null ? "Novo contato" : "Editar contato")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: _tNome,
                validator: _validarObrigatorio,
                decoration: InputDecoration(labelText: "Nome"),
              ),
              TextFormField(
                controller: _tTelefone,
                validator: _validarObrigatorio,
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(labelText: "Telefone"),
              ),
              TextFormField(
                controller: _tEmail,
                validator: _validarEmail,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(labelText: "E-mail (opcional)"),
              ),
              SizedBox(height: 20),
              Text("Categoria"),
              DropdownButton<String>(
                value: _categoria,
                isExpanded: true,
                items: categorias.map((String c) {
                  return DropdownMenuItem<String>(value: c, child: Text(c));
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    _categoria = value!;
                  });
                },
              ),
              CheckboxListTile(
                title: Text("Favorito"),
                value: _favorito,
                onChanged: (bool? value) {
                  setState(() {
                    _favorito = value!;
                  });
                },
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  OutlinedButton(
                    onPressed: () {
                      Navigator.pop(context); // volta sem salvar (retorna null)
                    },
                    child: Text("Cancelar"),
                  ),
                  ElevatedButton(onPressed: _salvar, child: Text("Salvar")),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ====================== TELA 3: DETALHE ======================
class TelaDetalhe extends StatefulWidget {
  final Contato contato;

  TelaDetalhe(this.contato);

  @override
  State<TelaDetalhe> createState() => _TelaDetalheState();
}

class _TelaDetalheState extends State<TelaDetalhe> {
  String _mensagem = "";

  void _editar() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => TelaCadastro(contato: widget.contato)),
    );
    setState(() {}); // redesenha com os dados novos
  }

  void _excluir() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Excluir"),
          content: Text("Deseja excluir " + widget.contato.nome + "?"),
          actions: [
            TextButton(
              child: Text("Não"),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            TextButton(
              child: Text("Sim"),
              onPressed: () {
                contatos.remove(widget.contato);
                Navigator.pop(context); // fecha o diálogo
                Navigator.pop(context); // volta para a lista
              },
            ),
          ],
        );
      },
    );
  }

  // Função de reuso: uma linha de informação
  Widget linhaInfo(String titulo, String valor) {
    return Padding(
      padding: EdgeInsets.all(8),
      child: Row(
        children: [
          Text(titulo + ": ", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Expanded(child: Text(valor, style: TextStyle(fontSize: 18))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Contato contato = widget.contato;

    return Scaffold(
      appBar: AppBar(
        title: Text(contato.nome),
        actions: [
          IconButton(icon: Icon(Icons.edit), onPressed: _editar),
          IconButton(icon: Icon(Icons.delete), onPressed: _excluir),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            CircleAvatar(
              radius: 50,
              child: Text(contato.nome[0].toUpperCase(), style: TextStyle(fontSize: 40)),
            ),
            Padding(
              padding: EdgeInsets.all(15),
              child: Text(
                contato.nome,
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.teal.shade900),
              ),
            ),
            Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.teal.shade50,
                border: Border.all(width: 1, color: Colors.teal),
              ),
              child: Column(
                children: [
                  linhaInfo("Telefone", contato.telefone),
                  linhaInfo("E-mail", contato.email.isEmpty ? "não informado" : contato.email),
                  linhaInfo("Categoria", contato.categoria),
                  linhaInfo("Favorito", contato.favorito ? "Sim" : "Não"),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.all(20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _mensagem = "Ligando para " + contato.nome + "...";
                      });
                    },
                    child: Text("Ligar"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text("Voltar"),
                  ),
                ],
              ),
            ),
            Text(_mensagem, style: TextStyle(fontSize: 18, color: Colors.teal)),
          ],
        ),
      ),
    );
  }
}
