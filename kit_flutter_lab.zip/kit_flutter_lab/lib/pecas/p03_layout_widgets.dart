// PEÇA 03 - Widgets de interface e layout (Aula 3)
// Container, Row, Column, Padding, texto formatado, imagem, botões, Card,
// Scaffold com bottomNavigationBar.
// Para rodar sozinha: flutter run -t lib/pecas/p03_layout_widgets.dart

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(debugShowCheckedModeBanner: false, home: TelaLayout()));
}

class TelaLayout extends StatelessWidget {
  // Função de reuso (Aula 3)
  Text formatarTexto(String texto) {
    return Text(texto, style: TextStyle(fontSize: 20, color: Colors.black));
  }

  // Função de reuso: título de seção
  Widget titulo(String texto) {
    return Padding(
      padding: EdgeInsets.only(top: 20, bottom: 8),
      child: Text(
        texto,
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Layout e widgets")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            titulo("Texto formatado"),
            Text(
              "Texto Formatado",
              style: TextStyle(
                fontSize: 24,
                color: Colors.blue,
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic,
                decoration: TextDecoration.underline,
                letterSpacing: 2,
              ),
            ),
            formatarTexto("Texto pela função de reuso"),

            titulo("Row com alinhamento"),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [Text("Item 1"), Text("Item 2"), Text("Item 3")],
            ),

            titulo("Container (padding, margin, borda, cor)"),
            Container(
              width: double.infinity, // ocupa a largura toda
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.only(left: 10, top: 10, right: 10),
              decoration: BoxDecoration(
                color: Colors.amber.shade100,
                border: Border.all(width: 2, color: Colors.amber),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text("Dentro do Container"),
            ),

            titulo("Padding"),
            Padding(
              padding: EdgeInsets.all(10),
              child: Text("Texto com espaçamento"),
            ),

            titulo("Expanded (divide o espaço da Row)"),
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Container(height: 40, color: Colors.red.shade200, child: Center(child: Text("2/3"))),
                ),
                Expanded(
                  flex: 1,
                  child: Container(height: 40, color: Colors.green.shade200, child: Center(child: Text("1/3"))),
                ),
              ],
            ),

            titulo("Imagens"),
            Row(
              children: [
                // Precisa da pasta assets/ declarada no pubspec.yaml
                Image.asset("assets/imagem.jpg", width: 100, height: 100, fit: BoxFit.cover),
                SizedBox(width: 15), // espaço entre widgets
                // Foto redonda
                CircleAvatar(radius: 40, backgroundImage: AssetImage("assets/imagem.jpg")),
                SizedBox(width: 15),
                // Sem imagem: ícone ou inicial
                CircleAvatar(radius: 30, child: Text("L")),
                SizedBox(width: 15),
                Icon(Icons.star, size: 40, color: Colors.orange),
              ],
            ),
            // Imagem da internet: Image.network("https://...", height: 100)

            titulo("Botões"),
            Wrap(
              spacing: 10, // Wrap quebra a linha sozinho quando não cabe
              children: [
                ElevatedButton(
                  onPressed: () {
                    print("Botão pressionado!");
                  },
                  child: Text("Elevated"),
                ),
                TextButton(onPressed: () {}, child: Text("Text")),
                OutlinedButton(onPressed: () {}, child: Text("Outlined")),
                IconButton(onPressed: () {}, icon: Icon(Icons.favorite)),
                ElevatedButton.icon(
                  onPressed: () {},
                  icon: Icon(Icons.add),
                  label: Text("Com ícone"),
                ),
              ],
            ),

            titulo("Card + ListTile"),
            Card(
              child: ListTile(
                leading: Icon(Icons.person),
                title: Text("Título"),
                subtitle: Text("Subtítulo"),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {},
              ),
            ),

            titulo("Centralizar"),
            Center(child: Text("No centro")),
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.maybePop(context);
              },
              child: Text("Voltar"),
            ),
            Text("Rodapé"),
          ],
        ),
      ),
    );
  }
}
