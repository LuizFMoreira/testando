// PEÇA 04 - Entrada de dados (Aula 3)
// TextField, TextFormField com validação (Form), Checkbox, CheckboxListTile,
// Radio, Switch, Dropdown, Slider. Cada bloco é independente: copie só o que precisar.
// Para rodar sozinha: flutter run -t lib/pecas/p04_inputs.dart

// ignore_for_file: deprecated_member_use
// (o groupValue do Radio é o jeito ensinado na aula; ainda funciona)

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(debugShowCheckedModeBanner: false, home: TelaInputs()));
}

class TelaInputs extends StatefulWidget {
  @override
  _TelaInputsState createState() => _TelaInputsState();
}

class _TelaInputsState extends State<TelaInputs> {
  // Chave do formulário: usada para validar todos os campos de uma vez
  final _formKey = GlobalKey<FormState>();

  final _tNome = TextEditingController();
  final _tIdade = TextEditingController();
  final _tSenha = TextEditingController();

  bool _aceito = false; // Checkbox
  bool _notificacoes = true; // Switch
  int _escolhaUsuario = 1; // Radio
  String _curso = "Engenharia de Software"; // Dropdown
  double _nota = 5; // Slider

  List<String> cursos = ["Engenharia de Software", "Ciência da Computação", "Sistemas de Informação"];

  String _resultado = "";

  // Validadores: devolvem o texto do erro, ou null se estiver certo
  String? _validarObrigatorio(String? text) {
    if (text == null || text.trim().isEmpty) {
      return "Campo obrigatório";
    }
    return null;
  }

  String? _validarIdade(String? text) {
    if (text == null || text.isEmpty) {
      return "Campo obrigatório";
    }
    int? idade = int.tryParse(text);
    if (idade == null) {
      return "Digite apenas números";
    }
    if (idade < 0 || idade > 120) {
      return "Idade inválida";
    }
    return null;
  }

  void _enviar() {
    // validate() roda o validator de todos os TextFormField do Form
    if (!_formKey.currentState!.validate()) {
      return;
    }
    if (!_aceito) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Você precisa aceitar os termos")),
      );
      return;
    }
    setState(() {
      _resultado = "Nome: " + _tNome.text +
          "\nIdade: " + _tIdade.text +
          "\nCurso: " + _curso +
          "\nTurno: " + (_escolhaUsuario == 1 ? "Manhã" : "Noite") +
          "\nNota: " + _nota.toStringAsFixed(0) +
          "\nNotificações: " + (_notificacoes ? "sim" : "não");
    });
  }

  void _limpar() {
    _formKey.currentState!.reset();
    setState(() {
      _tNome.clear();
      _tIdade.clear();
      _tSenha.clear();
      _aceito = false;
      _resultado = "";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Entrada de dados")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(15),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ---------- Texto com validação ----------
              TextFormField(
                controller: _tNome,
                validator: _validarObrigatorio,
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  labelText: "Nome",
                  hintText: "Digite seu nome",
                  prefixIcon: Icon(Icons.person),
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10),

              // ---------- Número ----------
              TextFormField(
                controller: _tIdade,
                validator: _validarIdade,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: "Idade", border: OutlineInputBorder()),
              ),
              SizedBox(height: 10),

              // ---------- Senha (TextField simples, sem validação) ----------
              TextField(
                controller: _tSenha,
                obscureText: true, // esconde o texto
                maxLength: 8,
                decoration: InputDecoration(labelText: "Senha"),
                onChanged: (String texto) {
                  print("Digitando: " + texto);
                },
                onSubmitted: (String texto) {
                  print("Digitado: " + texto);
                },
              ),

              // ---------- Dropdown ----------
              Text("Curso"),
              DropdownButton<String>(
                value: _curso,
                isExpanded: true,
                items: cursos.map((String c) {
                  return DropdownMenuItem<String>(value: c, child: Text(c));
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    _curso = value!;
                  });
                },
              ),

              // ---------- Radio ----------
              RadioListTile(
                title: Text("Manhã"),
                value: 1,
                groupValue: _escolhaUsuario,
                onChanged: (int? value) {
                  setState(() {
                    _escolhaUsuario = value!;
                  });
                },
              ),
              RadioListTile(
                title: Text("Noite"),
                value: 2,
                groupValue: _escolhaUsuario,
                onChanged: (int? value) {
                  setState(() {
                    _escolhaUsuario = value!;
                  });
                },
              ),

              // ---------- Slider ----------
              Text("Nota: " + _nota.toStringAsFixed(0)),
              Slider(
                value: _nota,
                min: 0,
                max: 10,
                divisions: 10,
                label: _nota.toStringAsFixed(0),
                onChanged: (double value) {
                  setState(() {
                    _nota = value;
                  });
                },
              ),

              // ---------- Switch ----------
              SwitchListTile(
                title: Text("Receber notificações"),
                value: _notificacoes,
                onChanged: (bool value) {
                  setState(() {
                    _notificacoes = value;
                  });
                },
              ),

              // ---------- Checkbox com título ----------
              CheckboxListTile(
                title: Text("Aceito os termos"),
                value: _aceito,
                onChanged: (bool? value) {
                  setState(() {
                    _aceito = value!;
                  });
                },
              ),

              // ---------- Checkbox "solto" ----------
              Row(
                children: [
                  Checkbox(
                    value: _aceito,
                    onChanged: (bool? value) {
                      setState(() {
                        _aceito = value!;
                      });
                    },
                  ),
                  Expanded(child: Text("Mesmo checkbox, sem ListTile")),
                ],
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(onPressed: _enviar, child: Text("Enviar")),
                  OutlinedButton(onPressed: _limpar, child: Text("Limpar")),
                ],
              ),
              Padding(
                padding: EdgeInsets.all(15),
                child: Text(_resultado, style: TextStyle(fontSize: 18)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
