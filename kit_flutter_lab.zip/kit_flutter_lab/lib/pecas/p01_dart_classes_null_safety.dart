// PEÇA 01 - Dart: classes, construtores, listas e null safety (Aulas 0 e 2)
// Não tem tela bonita: é a "cola" de Dart. A tela só imprime os resultados.
// Para rodar sozinha: flutter run -t lib/pecas/p01_dart_classes_null_safety.dart

// ignore_for_file: dead_code, unnecessary_non_null_assertion, prefer_initializing_formals
// (os avisos são de propósito: o exemplo mostra justamente esses operadores)

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(debugShowCheckedModeBanner: false, home: TelaDart()));
}

// ---------- 1. Construtor posicional (jeito "longo") ----------
class PessoaLonga {
  String nome = "";
  int idade = 0;

  PessoaLonga(String nome, int idade) {
    this.nome = nome;
    this.idade = idade;
  }
}

// ---------- 2. Construtor posicional curto ----------
class Pessoa {
  String nome;
  int idade;

  Pessoa(this.nome, this.idade);
}

// ---------- 3. Parâmetros nomeados, obrigatório e opcional com valor padrão ----------
class Aluno {
  String nome;
  int idade;
  String? apelido; // pode ser null (null safety)

  Aluno({required this.nome, this.idade = 18, this.apelido});

  // Método da classe
  String apresentar() {
    // ?? = valor padrão caso seja null
    return nome + " (" + (apelido ?? "sem apelido") + "), " + idade.toString() + " anos";
  }
}

// ---------- 4. late: inicializa depois, mas garante que não é null ----------
class Funcionario {
  late int numero;

  Funcionario() {
    numero = calcular();
  }

  int calcular() {
    return 10;
  }
}

// ---------- 5. Listas ----------
List<String> exemplosDeLista() {
  List<String> saida = [];

  List<String> carros = ["Gol", "Fusca", "Ka"];
  carros.add("Uno"); // adiciona no fim
  carros.insert(0, "Palio"); // adiciona na posição
  carros.remove("Fusca"); // remove pelo valor
  carros.removeAt(0); // remove pela posição
  saida.add("carros = " + carros.toString());
  saida.add("tamanho = " + carros.length.toString());
  saida.add("primeiro = " + carros[0] + " | ultimo = " + carros.last);
  saida.add("contem Ka? " + carros.contains("Ka").toString());
  saida.add("indice do Ka = " + carros.indexOf("Ka").toString());

  // Percorrer
  for (int i = 0; i < carros.length; i++) {
    saida.add("for: " + i.toString() + " -> " + carros[i]);
  }
  for (String c in carros) {
    saida.add("for in: " + c);
  }

  // Lista de objetos
  List<Pessoa> pessoas = [Pessoa("Ana", 30), Pessoa("Bia", 17), Pessoa("Caio", 22)];
  pessoas.add(Pessoa("Duda", 15));

  // Filtrar (where) -> precisa do toList()
  List<Pessoa> maiores = pessoas.where((p) => p.idade >= 18).toList();
  saida.add("maiores de idade = " + maiores.length.toString());

  // Transformar (map)
  List<String> nomes = pessoas.map((p) => p.nome).toList();
  saida.add("nomes = " + nomes.join(", "));

  // Somar
  int soma = 0;
  for (Pessoa p in pessoas) {
    soma = soma + p.idade;
  }
  saida.add("soma das idades = " + soma.toString());
  saida.add("media = " + (soma / pessoas.length).toStringAsFixed(1));

  // Ordenar
  pessoas.sort((a, b) => a.nome.compareTo(b.nome)); // por texto
  pessoas.sort((a, b) => a.idade.compareTo(b.idade)); // por número
  saida.add("mais novo = " + pessoas.first.nome);

  // Remover com condição
  pessoas.removeWhere((p) => p.idade < 18);
  saida.add("sobrou = " + pessoas.length.toString());

  return saida;
}

// ---------- 6. Null safety ----------
List<String> exemplosNullSafety() {
  List<String> saida = [];

  int? numero; // ? = pode ser null
  saida.add("numero = " + numero.toString()); // null

  numero = 10;
  int resposta = numero; // aqui o Dart já sabe que não é null
  saida.add("resposta = " + resposta.toString());

  String? nome;
  String texto = nome ?? "Nome padrão"; // ?? = se for null usa o outro
  saida.add("texto = " + texto);

  // ?. = só acessa se não for null
  saida.add("tamanho = " + (nome?.length).toString()); // null

  // ! = "eu garanto que não é null" (se for, dá erro na execução)
  String? cidade = "BH";
  saida.add("cidade = " + cidade!.toUpperCase());

  // Conversão segura de texto para número (não quebra se digitar errado)
  int? idade = int.tryParse("abc"); // null
  double? preco = double.tryParse("9.90"); // 9.9
  saida.add("idade = " + idade.toString() + " | preco = " + preco.toString());

  // Listas
  List<String?> comNulo = ["Gol", null, "Ka"]; // elementos podem ser null
  List<String>? listaNula; // a lista pode ser null
  saida.add("comNulo = " + comNulo.toString());
  saida.add("listaNula = " + listaNula.toString());

  return saida;
}

class TelaDart extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var aluno = Aluno(nome: "Adriano", idade: 30);
    var aluna = Aluno(idade: 21, nome: "Marcia", apelido: "Ma");
    var novato = Aluno(nome: "Luiz"); // idade vira 18 sozinho

    List<String> linhas = [];
    linhas.add("--- CLASSES ---");
    linhas.add(aluno.apresentar());
    linhas.add(aluna.apresentar());
    linhas.add(novato.apresentar());
    linhas.add("Funcionario.numero = " + Funcionario().numero.toString());
    linhas.add("--- LISTAS ---");
    linhas.addAll(exemplosDeLista());
    linhas.add("--- NULL SAFETY ---");
    linhas.addAll(exemplosNullSafety());

    return Scaffold(
      appBar: AppBar(title: Text("Dart: classes e null safety")),
      body: ListView.builder(
        padding: EdgeInsets.all(15),
        itemCount: linhas.length,
        itemBuilder: (context, index) {
          return Text(linhas[index], style: TextStyle(fontSize: 16));
        },
      ),
    );
  }
}
