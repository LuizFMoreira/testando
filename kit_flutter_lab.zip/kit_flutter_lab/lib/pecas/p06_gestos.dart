// PEÇA 06 - Gestos (Aula 5)
// GestureDetector (onTap, onDoubleTap, onLongPress) + jogo com Random.
// Mudando a lista "opcoes" vira Cara ou Coroa, Pedra/Papel/Tesoura, Par ou Ímpar, dado...
// Para rodar sozinha: flutter run -t lib/pecas/p06_gestos.dart

import 'dart:math';

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(debugShowCheckedModeBanner: false, home: Jogo()));
}

class Jogo extends StatefulWidget {
  @override
  _JogoState createState() => _JogoState();
}

class _JogoState extends State<Jogo> {
  // Cara ou coroa: var opcoes = ["cara", "coroa"];
  var opcoes = ["pedra", "papel", "tesoura"];

  var _escolhaApp = "?";
  var _mensagem = "Escolha uma opção abaixo";
  int _vitorias = 0;
  int _derrotas = 0;
  int _empates = 0;

  void _opcaoSelecionada(String escolhaUsuario) {
    var numero = Random().nextInt(opcoes.length); // sorteia de 0 até length-1
    var escolhaApp = opcoes[numero];

    setState(() {
      _escolhaApp = escolhaApp;

      // Regra do Pedra/Papel/Tesoura.
      // Cara ou coroa: ganha se (escolhaUsuario == escolhaApp).
      if (escolhaUsuario == escolhaApp) {
        _mensagem = "Empate!";
        _empates++;
      } else if ((escolhaUsuario == "pedra" && escolhaApp == "tesoura") ||
          (escolhaUsuario == "papel" && escolhaApp == "pedra") ||
          (escolhaUsuario == "tesoura" && escolhaApp == "papel")) {
        _mensagem = "Parabéns!!! Você ganhou :)";
        _vitorias++;
      } else {
        _mensagem = "Você perdeu :(";
        _derrotas++;
      }
    });
  }

  void _zerar() {
    setState(() {
      _escolhaApp = "?";
      _mensagem = "Escolha uma opção abaixo";
      _vitorias = 0;
      _derrotas = 0;
      _empates = 0;
    });
  }

  // Desenha uma opção. Com imagens, troque o Container por:
  //   Image.asset("imagens/" + nome + ".png", height: 100)
  // e na escolha do app: Image(image: AssetImage("imagens/${_escolhaApp}.png"), height: 100)
  Widget _figura(String nome) {
    var icones = {
      "pedra": Icons.landscape,
      "papel": Icons.description,
      "tesoura": Icons.content_cut,
      "cara": Icons.face,
      "coroa": Icons.monetization_on,
    };
    return Container(
      width: 90,
      height: 90,
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        border: Border.all(width: 2, color: Colors.blue),
        borderRadius: BorderRadius.circular(45),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icones[nome] ?? Icons.help, size: 36, color: Colors.blue),
          Text(nome),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Jogo")),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 32, bottom: 16),
              child: Text(
                "Escolha do Computador",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            _figura(_escolhaApp),
            Padding(
              padding: EdgeInsets.only(top: 32, bottom: 16),
              child: Text(
                _mensagem,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // GestureDetector deixa qualquer widget "clicável"
                GestureDetector(
                  onTap: () => _opcaoSelecionada("pedra"),
                  child: _figura("pedra"),
                ),
                GestureDetector(
                  onTap: () => _opcaoSelecionada("papel"),
                  child: _figura("papel"),
                ),
                GestureDetector(
                  onTap: () => _opcaoSelecionada("tesoura"),
                  child: _figura("tesoura"),
                ),
              ],
            ),
            Padding(
              padding: EdgeInsets.all(25),
              child: Text(
                "Vitórias: $_vitorias   Derrotas: $_derrotas   Empates: $_empates",
                style: TextStyle(fontSize: 16),
              ),
            ),

            // Outros gestos no mesmo widget
            GestureDetector(
              onTap: () {
                print("Clicou uma vez");
              },
              onDoubleTap: () {
                // toque duplo zera o placar
                _zerar();
              },
              onLongPress: () {
                // segurar mostra um aviso
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Pressionou e segurou")),
                );
              },
              child: Container(
                padding: EdgeInsets.all(15),
                color: Colors.amber.shade100,
                child: Text("Toque duplo aqui zera o placar. Segure para ver o aviso."),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------
// OUTROS GESTOS DO GestureDetector:
//   onTapDown / onTapUp          -> encostou / soltou
//   onHorizontalDragEnd: (d) {}  -> arrastou para o lado
//   onVerticalDragEnd: (d) {}    -> arrastou para cima/baixo
//   onPanUpdate: (d) { d.delta.dx; d.delta.dy; } -> arrastando (mover objeto)
//
// InkWell faz o mesmo que o onTap, mas com o efeito de "onda" do Material:
//   InkWell(onTap: () {}, child: ...)
//
// Sortear número de 1 a 6 (dado): Random().nextInt(6) + 1
// ---------------------------------------------------------------
