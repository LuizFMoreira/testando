// PEÇA 05 - Tema com Material Design (Aula 4)
// Tema claro/escuro, ColorScheme.fromSeed, Theme.of(context), tema local,
// e o botão de alternar SEM precisar de Provider (estado no topo do app).
// Para rodar sozinha: flutter run -t lib/pecas/p05_tema.dart

import 'package:flutter/material.dart';

void main() {
  runApp(AppComTema());
}

// O MaterialApp fica dentro de um StatefulWidget: assim o setState troca o tema
// do app inteiro, e o MaterialApp continua sendo usado uma vez só.
class AppComTema extends StatefulWidget {
  @override
  State<AppComTema> createState() => _AppComTemaState();
}

class _AppComTemaState extends State<AppComTema> {
  bool _isDarkMode = false;
  Color _corSemente = Colors.purple;

  void _toggleTheme() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
  }

  void _trocarCor(Color cor) {
    setState(() {
      _corSemente = cor;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tema Personalizado',
      debugShowCheckedModeBanner: false,
      // Tema claro
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: _corSemente,
          brightness: Brightness.light,
        ),
        // Estilos de texto (nomes novos: headlineMedium, bodyMedium, titleLarge...)
        textTheme: TextTheme(
          headlineMedium: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          bodyMedium: TextStyle(fontSize: 16),
        ),
        // Tema de um componente: vale para todas as AppBars
        appBarTheme: AppBarTheme(
          backgroundColor: _corSemente,
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
        // Vale para todos os ElevatedButton
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(padding: EdgeInsets.all(15)),
        ),
        // Vale para todos os campos de texto
        inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder()),
      ),
      // Tema escuro
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: _corSemente,
          brightness: Brightness.dark,
        ),
      ),
      // Quem decide qual dos dois usar
      themeMode: _isDarkMode ? ThemeMode.dark : ThemeMode.light,
      home: TelaTema(_isDarkMode, _toggleTheme, _trocarCor),
    );
  }
}

class TelaTema extends StatelessWidget {
  final bool isDarkMode;
  final void Function() aoAlternar; // função recebida por parâmetro
  final void Function(Color) aoTrocarCor;

  TelaTema(this.isDarkMode, this.aoAlternar, this.aoTrocarCor);

  @override
  Widget build(BuildContext context) {
    // Pega as cores e textos do tema atual
    ColorScheme cores = Theme.of(context).colorScheme;
    TextTheme textos = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: Text('Tema Personalizado'),
        actions: [
          IconButton(
            icon: Icon(isDarkMode ? Icons.light_mode : Icons.dark_mode),
            onPressed: aoAlternar,
          ),
          // Só para fechar a peça quando aberta pelo menu do kit.
          // Se usar como app principal, pode apagar este botão.
          IconButton(
            icon: Icon(Icons.close),
            onPressed: () {
              Navigator.of(context, rootNavigator: true).maybePop();
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Texto com estilo de tema', style: textos.headlineMedium),
            Text('Texto de corpo (bodyMedium é o padrão do Text)'),
            SizedBox(height: 20),

            // Usando as cores do tema em vez de cor fixa
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(15),
              color: cores.primaryContainer,
              child: Text(
                "Container com cores.primaryContainer",
                style: TextStyle(color: cores.onPrimaryContainer),
              ),
            ),
            SizedBox(height: 20),

            SwitchListTile(
              title: Text("Modo escuro"),
              value: isDarkMode,
              onChanged: (bool value) {
                aoAlternar();
              },
            ),
            ElevatedButton(onPressed: aoAlternar, child: Text('Alternar Tema')),
            SizedBox(height: 20),

            Text("Cor do tema:"),
            Row(
              children: [
                IconButton(
                  icon: Icon(Icons.circle, color: Colors.purple),
                  onPressed: () => aoTrocarCor(Colors.purple),
                ),
                IconButton(
                  icon: Icon(Icons.circle, color: Colors.teal),
                  onPressed: () => aoTrocarCor(Colors.teal),
                ),
                IconButton(
                  icon: Icon(Icons.circle, color: Colors.orange),
                  onPressed: () => aoTrocarCor(Colors.orange),
                ),
                IconButton(
                  icon: Icon(Icons.circle, color: Colors.blue),
                  onPressed: () => aoTrocarCor(Colors.blue),
                ),
              ],
            ),
            SizedBox(height: 20),

            TextField(decoration: InputDecoration(labelText: "Campo com o tema")),
            SizedBox(height: 20),

            // Tema local: sobrescreve o tema só para o que está dentro
            Theme(
              data: Theme.of(context).copyWith(
                colorScheme: ColorScheme.fromSeed(seedColor: Colors.pink),
              ),
              child: ElevatedButton(
                onPressed: () {},
                child: Text('Botão com tema personalizado'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------
// VERSÃO MÍNIMA (tema fixo, sem alternar) - cabe direto no main():
//
// runApp(MaterialApp(
//   theme: ThemeData(
//     colorSchemeSeed: Colors.teal,
//     appBarTheme: AppBarTheme(backgroundColor: Colors.teal, foregroundColor: Colors.white),
//   ),
//   home: MinhaTela(),
// ));
//
// TEMA COM CORES PRÓPRIAS (customTheme da aula):
//
// ThemeData customTheme = ThemeData(
//   brightness: Brightness.light,
//   primaryColor: Color(0xFF3498DB),
//   scaffoldBackgroundColor: Color(0xFFf1f1f1),
// );
// ---------------------------------------------------------------
