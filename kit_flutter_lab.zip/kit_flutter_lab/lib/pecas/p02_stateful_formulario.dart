// PEÇA 02 - StatefulWidget + formulário com cálculo (Aula 1)
// Base para: IMC, média de notas, conversor, divisor de conta, álcool x gasolina...
// Troque os campos e a conta dentro de _calcular().
// Para rodar sozinha: flutter run -t lib/pecas/p02_stateful_formulario.dart

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    title: 'Calculadora',
    debugShowCheckedModeBanner: false,
    home: TelaCalculo(),
  ));
}

class TelaCalculo extends StatefulWidget {
  @override
  _TelaCalculoState createState() => _TelaCalculoState();
}

class _TelaCalculoState extends State<TelaCalculo> {
  // Um controller para cada campo de texto
  final _tPeso = TextEditingController();
  final _tAltura = TextEditingController();
  var _infoText = "Informe seus dados!";

  void _calcular() {
    // tryParse não quebra se o campo estiver vazio ou com letra.
    // replaceAll troca vírgula por ponto (teclado brasileiro).
    double? peso = double.tryParse(_tPeso.text.replaceAll(",", "."));
    double? alturaCm = double.tryParse(_tAltura.text.replaceAll(",", "."));

    if (peso == null || alturaCm == null || alturaCm == 0) {
      setState(() {
        _infoText = "Preencha os campos com números válidos";
      });
      return;
    }

    setState(() {
      double altura = alturaCm / 100;
      double imc = peso / (altura * altura);
      String imcStr = imc.toStringAsFixed(2); // 2 casas decimais

      if (imc < 18.5) {
        _infoText = "Abaixo do Peso ($imcStr)";
      } else if (imc < 25) {
        _infoText = "Peso Normal ($imcStr)";
      } else if (imc < 30) {
        _infoText = "Acima do Peso ($imcStr)";
      } else {
        _infoText = "Obesidade ($imcStr)";
      }
    });
  }

  void _limpar() {
    setState(() {
      _tPeso.clear();
      _tAltura.clear();
      _infoText = "Informe seus dados!";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Calculadora de IMC"),
        centerTitle: true,
        actions: [
          IconButton(icon: Icon(Icons.refresh), onPressed: _limpar),
        ],
      ),
      // SingleChildScrollView evita o erro de overflow quando o teclado abre
      body: SingleChildScrollView(
        padding: EdgeInsets.all(15.0),
        child: Column(
          children: <Widget>[
            _editText("Peso (kg)", _tPeso),
            _editText("Altura (cm)", _tAltura),
            Padding(
              padding: EdgeInsets.only(top: 15, bottom: 15),
              child: ElevatedButton(onPressed: _calcular, child: Text("Calcular")),
            ),
            Text(
              _infoText,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.blue, fontSize: 25.0),
            ),
          ],
        ),
      ),
    );
  }

  // Função de reuso: monta um campo de texto
  Widget _editText(String label, TextEditingController controller) {
    return TextFormField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(labelText: label),
    );
  }
}

// ---------------------------------------------------------------
// OUTRAS CONTAS PRONTAS (troque o miolo do _calcular):
//
// Média de 3 notas:
//   double media = (n1 + n2 + n3) / 3;
//   _infoText = media >= 60 ? "Aprovado ($media)" : "Reprovado ($media)";
//
// Álcool ou gasolina:
//   _infoText = (alcool / gasolina) < 0.7 ? "Abasteça com álcool" : "Abasteça com gasolina";
//
// Dividir conta com gorjeta:
//   double total = valor + (valor * gorjeta / 100);
//   double porPessoa = total / pessoas;
//
// Celsius para Fahrenheit:
//   double f = c * 9 / 5 + 32;
//
// Contador (sem campo de texto):
//   int _contador = 0;
//   void _somar() { setState(() { _contador++; }); }
// ---------------------------------------------------------------
