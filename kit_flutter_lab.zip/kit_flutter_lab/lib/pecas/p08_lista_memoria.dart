// PEÇA 08 - Aplicativo dinâmico com lista em memória (o básico)
// Classe + List<> + ListView.builder + adicionar + remover + marcar + contador.
// Tudo em uma tela só. É a base de: tarefas, compras, alunos, recados, filmes...
// Para rodar sozinha: flutter run -t lib/pecas/p08_lista_memoria.dart

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: Colors.indigo),
    home: ListaTarefas(),
  ));
}

// 1. A classe do item da lista
class Tarefa {
  String titulo;
  bool feita;

  Tarefa(this.titulo, {this.feita = false});
}

class ListaTarefas extends StatefulWidget {
  @override
  State<ListaTarefas> createState() => _ListaTarefasState();
}

class _ListaTarefasState extends State<ListaTarefas> {
  // 2. A lista em memória (some quando o app fecha).
  //    Fica DENTRO do State para o setState redesenhar a tela.
  List<Tarefa> tarefas = [
    Tarefa("Estudar Flutter"),
    Tarefa("Fazer o laboratório", feita: true),
  ];

  final _tTitulo = TextEditingController();

  // 3. Adicionar
  void _adicionar() {
    String texto = _tTitulo.text.trim();
    if (texto.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Digite alguma coisa")),
      );
      return;
    }
    setState(() {
      tarefas.add(Tarefa(texto));
      // tarefas.insert(0, Tarefa(texto)); // para entrar no topo
    });
    _tTitulo.clear();
  }

  // 4. Remover
  void _remover(int index) {
    setState(() {
      tarefas.removeAt(index);
    });
  }

  // 5. Alterar um item (marcar/desmarcar)
  void _marcar(int index, bool valor) {
    setState(() {
      tarefas[index].feita = valor;
    });
  }

  void _limparTudo() {
    setState(() {
      tarefas.clear();
      // tarefas.removeWhere((t) => t.feita); // só as feitas
    });
  }

  @override
  Widget build(BuildContext context) {
    // Contadores calculados a partir da lista
    int feitas = tarefas.where((t) => t.feita).length;

    return Scaffold(
      appBar: AppBar(
        title: Text("Tarefas (" + tarefas.length.toString() + ")"),
        actions: [
          IconButton(icon: Icon(Icons.delete_sweep), onPressed: _limparTudo),
        ],
      ),
      body: Column(
        children: [
          // ---------- Campo + botão de adicionar ----------
          Padding(
            padding: EdgeInsets.all(10),
            child: Row(
              children: [
                // Expanded: o campo ocupa o espaço que sobrar na Row
                Expanded(
                  child: TextField(
                    controller: _tTitulo,
                    decoration: InputDecoration(labelText: "Nova tarefa"),
                    onSubmitted: (String texto) {
                      _adicionar(); // Enter também adiciona
                    },
                  ),
                ),
                SizedBox(width: 10),
                ElevatedButton(onPressed: _adicionar, child: Text("Adicionar")),
              ],
            ),
          ),

          Text("Feitas: $feitas de ${tarefas.length}"),

          // ---------- A lista ----------
          // Expanded é OBRIGATÓRIO para ListView dentro de Column
          Expanded(
            child: tarefas.isEmpty
                ? Center(child: Text("Nenhuma tarefa cadastrada"))
                : ListView.builder(
                    itemCount: tarefas.length,
                    itemBuilder: (context, index) {
                      Tarefa tarefa = tarefas[index];
                      return ListTile(
                        leading: Checkbox(
                          value: tarefa.feita,
                          onChanged: (bool? value) {
                            _marcar(index, value!);
                          },
                        ),
                        title: Text(
                          tarefa.titulo,
                          style: TextStyle(
                            // risca o texto quando está feita
                            decoration: tarefa.feita ? TextDecoration.lineThrough : TextDecoration.none,
                          ),
                        ),
                        trailing: IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () {
                            _remover(index);
                          },
                        ),
                        onTap: () {
                          _marcar(index, !tarefa.feita);
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------
// VARIAÇÃO SEM ListView.builder (lista curta, com Column + map):
//
//   Column(
//     children: tarefas.map((t) => Text(t.titulo)).toList(),
//   )
//
// VARIAÇÃO COM LINHA SEPARADORA:
//
//   ListView.separated(
//     itemCount: tarefas.length,
//     separatorBuilder: (context, index) => Divider(),
//     itemBuilder: (context, index) { ... },
//   )
//
// LISTA SÓ DE TEXTO (sem classe):
//   List<String> nomes = [];   nomes.add(_tTitulo.text);   Text(nomes[index])
// ---------------------------------------------------------------
