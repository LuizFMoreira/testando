// PEÇA 10 - Duas telas: uma manda para a outra, e a outra tem botão de voltar
// Versão enxuta da peça 07 (Aula 6). Tela 1 envia o que foi digitado;
// Tela 2 mostra e volta.
// Para rodar sozinha: flutter run -t lib/pecas/p10_duas_telas.dart

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: Colors.blue),
    home: PrimeiraTela(),
  ));
}

// ====================== TELA 1 ======================
class PrimeiraTela extends StatefulWidget {
  @override
  State<PrimeiraTela> createState() => _PrimeiraTelaState();
}

class _PrimeiraTelaState extends State<PrimeiraTela> {
  final _tNome = TextEditingController();

  void _irParaSegunda() {
    // Não deixa ir com o campo vazio
    if (_tNome.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Digite o nome")),
      );
      return;
    }
    // push = coloca a nova tela em cima da atual
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => SegundaTela(_tNome.text)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Primeira Tela")),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: _tNome,
              decoration: InputDecoration(labelText: "Nome"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _irParaSegunda,
              child: Text("Próxima Tela"),
            ),
          ],
        ),
      ),
    );
  }
}

// ====================== TELA 2 ======================
class SegundaTela extends StatelessWidget {
  // O que a tela recebe vem pelo construtor
  final String nome;

  SegundaTela(this.nome);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // O AppBar já ganha a seta de voltar sozinho quando a tela veio de um push
      appBar: AppBar(title: Text("Segunda Tela")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Olá, " + nome + "!", style: TextStyle(fontSize: 26)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // pop = tira esta tela da pilha e volta para a anterior
                Navigator.pop(context);
              },
              child: Text("Voltar"),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------
// VARIAÇÕES (troque só o trecho indicado)
//
// A) SEM enviar nada: tire o campo "nome" e o construtor da SegundaTela e chame
//      MaterialPageRoute(builder: (context) => SegundaTela())
//
// B) Enviar MAIS de um valor:
//      final String nome;  final int idade;
//      SegundaTela(this.nome, this.idade);
//      ... => SegundaTela(_tNome.text, int.tryParse(_tIdade.text) ?? 0)
//
// C) Enviar um OBJETO (ex.: item de uma lista):
//      final Contato contato;
//      SegundaTela(this.contato);
//      ... => SegundaTela(contatos[index])       e na tela: Text(contato.nome)
//
// D) A segunda tela DEVOLVE um valor ao voltar:
//      na Tela 2:  Navigator.pop(context, "texto de volta");
//      na Tela 1:  void _irParaSegunda() async {
//                    var retorno = await Navigator.push(context, MaterialPageRoute(...));
//                    setState(() { _resposta = retorno ?? "nada"; });
//                  }
//
// E) Seta de voltar com ação própria no AppBar:
//      appBar: AppBar(
//        leading: IconButton(icon: Icon(Icons.arrow_back), onPressed: () { Navigator.pop(context); }),
//      )
//
// F) Terceira tela + "voltar direto para o início":
//      Navigator.popUntil(context, (route) => route.isFirst);
//
// G) Segunda tela Stateful: o parâmetro é lido com  widget.nome
// ---------------------------------------------------------------
