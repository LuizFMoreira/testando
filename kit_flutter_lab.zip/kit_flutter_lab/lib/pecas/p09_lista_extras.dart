// PEÇA 09 - Lista em memória: os "extras" que o professor pode pedir
// Item com vários campos, total (soma), busca/filtro, ordenar, editar em diálogo,
// arrastar para excluir (Dismissible), confirmar exclusão, SnackBar com desfazer,
// botão flutuante (FAB) e mensagem de lista vazia.
// Para rodar sozinha: flutter run -t lib/pecas/p09_lista_extras.dart

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: Colors.green),
    home: ListaCompras(),
  ));
}

class Produto {
  String nome;
  int quantidade;
  double preco;
  bool comprado;

  Produto(this.nome, this.quantidade, this.preco, {this.comprado = false});

  // Valor calculado
  double get subtotal => quantidade * preco;
}

class ListaCompras extends StatefulWidget {
  @override
  State<ListaCompras> createState() => _ListaComprasState();
}

class _ListaComprasState extends State<ListaCompras> {
  List<Produto> produtos = [
    Produto("Arroz", 2, 25.90),
    Produto("Feijão", 1, 8.50),
    Produto("Café", 3, 18.00, comprado: true),
  ];

  String _busca = ""; // texto do filtro
  bool _soPendentes = false;

  // ---------- Contas em cima da lista ----------
  double _total() {
    double soma = 0;
    for (Produto p in produtos) {
      soma = soma + p.subtotal;
    }
    return soma;
  }

  // ---------- Filtro: devolve só o que deve aparecer ----------
  List<Produto> _filtrados() {
    return produtos.where((p) {
      bool bateTexto = p.nome.toLowerCase().contains(_busca.toLowerCase());
      bool bateStatus = !_soPendentes || !p.comprado;
      return bateTexto && bateStatus;
    }).toList();
  }

  // ---------- Ordenar ----------
  void _ordenarPorNome() {
    setState(() {
      produtos.sort((a, b) => a.nome.toLowerCase().compareTo(b.nome.toLowerCase()));
    });
  }

  void _ordenarPorPreco() {
    setState(() {
      produtos.sort((a, b) => b.subtotal.compareTo(a.subtotal)); // maior primeiro
    });
  }

  // ---------- Remover com "desfazer" ----------
  void _remover(Produto produto) {
    int posicao = produtos.indexOf(produto);
    setState(() {
      produtos.remove(produto);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(produto.nome + " removido"),
        action: SnackBarAction(
          label: "Desfazer",
          onPressed: () {
            setState(() {
              produtos.insert(posicao, produto);
            });
          },
        ),
      ),
    );
  }

  // ---------- Diálogo de confirmação ----------
  void _confirmarLimpar() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Limpar lista"),
          content: Text("Deseja apagar todos os itens?"),
          actions: [
            TextButton(
              child: Text("Cancelar"),
              onPressed: () {
                Navigator.pop(context); // fecha o diálogo
              },
            ),
            TextButton(
              child: Text("Apagar"),
              onPressed: () {
                setState(() {
                  produtos.clear();
                });
                Navigator.pop(context);
              },
            ),
          ],
        );
      },
    );
  }

  // ---------- Diálogo com formulário: serve para ADICIONAR e para EDITAR ----------
  // Se "produto" vier null, é cadastro novo. Se vier preenchido, é edição.
  void _abrirFormulario({Produto? produto}) {
    final tNome = TextEditingController(text: produto?.nome ?? "");
    final tQtd = TextEditingController(text: produto?.quantidade.toString() ?? "1");
    final tPreco = TextEditingController(text: produto?.preco.toStringAsFixed(2) ?? "");

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(produto == null ? "Novo item" : "Editar item"),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min, // diálogo só do tamanho do conteúdo
              children: [
                TextField(
                  controller: tNome,
                  autofocus: true,
                  decoration: InputDecoration(labelText: "Nome"),
                ),
                TextField(
                  controller: tQtd,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: "Quantidade"),
                ),
                TextField(
                  controller: tPreco,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: "Preço (R\$)"),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              child: Text("Cancelar"),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            ElevatedButton(
              child: Text("Salvar"),
              onPressed: () {
                String nome = tNome.text.trim();
                int qtd = int.tryParse(tQtd.text) ?? 1;
                double preco = double.tryParse(tPreco.text.replaceAll(",", ".")) ?? 0;
                if (nome.isEmpty) {
                  return; // não salva sem nome
                }
                setState(() {
                  if (produto == null) {
                    produtos.add(Produto(nome, qtd, preco));
                  } else {
                    produto.nome = nome;
                    produto.quantidade = qtd;
                    produto.preco = preco;
                  }
                });
                Navigator.pop(context);
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    List<Produto> visiveis = _filtrados();

    return Scaffold(
      appBar: AppBar(
        title: Text("Lista de Compras"),
        actions: [
          // Menu de três pontinhos
          PopupMenuButton<String>(
            onSelected: (String opcao) {
              if (opcao == "nome") _ordenarPorNome();
              if (opcao == "preco") _ordenarPorPreco();
              if (opcao == "limpar") _confirmarLimpar();
            },
            itemBuilder: (context) => [
              PopupMenuItem(value: "nome", child: Text("Ordenar por nome")),
              PopupMenuItem(value: "preco", child: Text("Ordenar por valor")),
              PopupMenuItem(value: "limpar", child: Text("Limpar lista")),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // ---------- Busca ----------
          Padding(
            padding: EdgeInsets.all(10),
            child: TextField(
              decoration: InputDecoration(
                labelText: "Buscar",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: (String texto) {
                setState(() {
                  _busca = texto;
                });
              },
            ),
          ),
          SwitchListTile(
            title: Text("Mostrar só os pendentes"),
            value: _soPendentes,
            onChanged: (bool value) {
              setState(() {
                _soPendentes = value;
              });
            },
          ),

          // ---------- Lista ----------
          Expanded(
            child: visiveis.isEmpty
                ? Center(child: Text("Nenhum item encontrado"))
                : ListView.builder(
                    itemCount: visiveis.length,
                    itemBuilder: (context, index) {
                      Produto produto = visiveis[index];
                      // Dismissible: arrastar para o lado remove
                      return Dismissible(
                        key: ObjectKey(produto), // identificador único do item
                        direction: DismissDirection.endToStart,
                        background: Container(
                          color: Colors.red,
                          alignment: Alignment.centerRight,
                          padding: EdgeInsets.only(right: 20),
                          child: Icon(Icons.delete, color: Colors.white),
                        ),
                        onDismissed: (direction) {
                          _remover(produto);
                        },
                        child: Card(
                          margin: EdgeInsets.only(left: 10, right: 10, top: 6),
                          child: ListTile(
                            leading: CircleAvatar(child: Text(produto.quantidade.toString())),
                            title: Text(
                              produto.nome,
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                decoration: produto.comprado ? TextDecoration.lineThrough : null,
                              ),
                            ),
                            subtitle: Text(
                              "R\$ " + produto.preco.toStringAsFixed(2) +
                                  " un.  |  Subtotal: R\$ " + produto.subtotal.toStringAsFixed(2),
                            ),
                            trailing: Checkbox(
                              value: produto.comprado,
                              onChanged: (bool? value) {
                                setState(() {
                                  produto.comprado = value!;
                                });
                              },
                            ),
                            // toque: editar
                            onTap: () {
                              _abrirFormulario(produto: produto);
                            },
                            // segurar: remover
                            onLongPress: () {
                              _remover(produto);
                            },
                          ),
                        ),
                      );
                    },
                  ),
          ),

          // ---------- Rodapé com o total ----------
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(15),
            color: Colors.green.shade100,
            child: Text(
              "Itens: " + produtos.length.toString() + "   |   Total: R\$ " + _total().toStringAsFixed(2),
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
      floatingActionButton: Padding(
        padding: EdgeInsets.only(bottom: 55), // para não ficar em cima do rodapé
        child: FloatingActionButton(
          onPressed: () {
            _abrirFormulario();
          },
          child: Icon(Icons.add),
        ),
      ),
    );
  }
}
