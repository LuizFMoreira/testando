// PEÇA 07 - Navegação (Aula 6)
// push, pop, passar parâmetro pelo construtor, receber resposta da outra tela,
// rotas nomeadas e pushReplacement.
// Para rodar sozinha: flutter run -t lib/pecas/p07_navegacao.dart

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    // Rotas nomeadas. Use "home" OU "initialRoute" com a rota "/", não os dois.
    initialRoute: "/",
    routes: {
      "/": (context) => TelaPrincipal(),
      "/secundaria": (context) => TelaSecundaria("vim pela rota nomeada"),
      "/sobre": (context) => TelaSobre(),
    },
  ));
}

class TelaPrincipal extends StatefulWidget {
  @override
  State<TelaPrincipal> createState() => _TelaPrincipalState();
}

class _TelaPrincipalState extends State<TelaPrincipal> {
  final _tNome = TextEditingController();
  String _resposta = "Nenhuma resposta ainda";

  // 3. Abre a tela e ESPERA ela devolver um valor no pop (async/await)
  void _abrirEsperandoResposta() async {
    var retorno = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => TelaPergunta()),
    );
    // Se o usuário voltar pela seta, retorno vem null
    setState(() {
      _resposta = "Resposta: " + (retorno ?? "voltou sem responder").toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tela Principal"),
        backgroundColor: Colors.black12,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _tNome,
              decoration: InputDecoration(labelText: "Texto para enviar"),
            ),
            SizedBox(height: 15),

            // 1. Navegação simples
            ElevatedButton(
              child: Text("Próxima Tela (push)"),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TelaSecundaria("teste")),
                );
              },
            ),

            // 2. Passando parâmetro (o que foi digitado)
            ElevatedButton(
              child: Text("Enviar o texto digitado"),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TelaSecundaria(_tNome.text)),
                );
              },
            ),

            // 3. Recebendo resposta
            ElevatedButton(
              onPressed: _abrirEsperandoResposta,
              child: Text("Abrir e esperar resposta"),
            ),
            Padding(
              padding: EdgeInsets.all(10),
              child: Text(_resposta, textAlign: TextAlign.center, style: TextStyle(fontSize: 18)),
            ),

            // 4. Rota nomeada (só funciona se a rota estiver no MaterialApp)
            ElevatedButton(
              child: Text("Rota nomeada (pushNamed)"),
              onPressed: () {
                Navigator.pushNamed(context, "/secundaria");
              },
            ),

            // 5. Troca a tela atual pela nova (não dá para voltar) - ex.: depois do login
            ElevatedButton(
              child: Text("Substituir tela (pushReplacement)"),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => TelaSobre()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

// Tela que RECEBE parâmetro pelo construtor
class TelaSecundaria extends StatelessWidget {
  final String parametro;

  TelaSecundaria(this.parametro);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tela Secundária"),
        backgroundColor: Colors.blue,
      ),
      body: Container(
        padding: EdgeInsets.all(15),
        child: Column(
          children: <Widget>[
            Text("Recebi: " + parametro, style: TextStyle(fontSize: 20)),
            SizedBox(height: 15),
            ElevatedButton(
              child: Text("Voltar (pop)"),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}

// Tela que DEVOLVE um valor para quem abriu
class TelaPergunta extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Você gosta de Flutter?")),
      body: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton(
              child: Text("Sim"),
              onPressed: () {
                Navigator.pop(context, "Sim"); // o 2º parâmetro é o retorno
              },
            ),
            ElevatedButton(
              child: Text("Não"),
              onPressed: () {
                Navigator.pop(context, "Não");
              },
            ),
          ],
        ),
      ),
    );
  }
}

class TelaSobre extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Sobre")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Essa tela substituiu a anterior."),
            SizedBox(height: 15),
            ElevatedButton(
              child: Text("Ir para o início"),
              onPressed: () {
                // Abre a tela inicial e apaga todas as outras da pilha
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => TelaPrincipal()),
                  (route) => route.isFirst,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------
// PARÂMETRO SENDO UM OBJETO (o mais comum com lista):
//
//   class TelaDetalhe extends StatelessWidget {
//     final Contato contato;
//     TelaDetalhe(this.contato);
//     ...  Text(contato.nome)
//   }
//   Navigator.push(context, MaterialPageRoute(builder: (context) => TelaDetalhe(contatos[index])));
//
// Em tela Stateful, o parâmetro é lido com "widget.":  widget.contato.nome
//
// PARÂMETRO EM ROTA NOMEADA:
//   Navigator.pushNamed(context, "/secundaria", arguments: "teste");
//   // na tela de destino, dentro do build:
//   var texto = ModalRoute.of(context)!.settings.arguments as String;
// ---------------------------------------------------------------
