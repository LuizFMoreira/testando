// Abre cada peça e exercita o fluxo principal das listas, para pegar erro de
// layout (overflow) e de lógica antes da atividade.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kit_flutter_lab/apps/app_crud_completo.dart';
import 'package:kit_flutter_lab/main.dart';
import 'package:kit_flutter_lab/pecas/p02_stateful_formulario.dart';
import 'package:kit_flutter_lab/pecas/p08_lista_memoria.dart';
import 'package:kit_flutter_lab/pecas/p09_lista_extras.dart';

void main() {
  testesDuasTelas();
  for (Peca peca in pecas) {
    testWidgets('abre sem erro: ' + peca.titulo, (tester) async {
      // tela de celular pequeno
      tester.view.physicalSize = Size(360, 640);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);

      await tester.pumpWidget(MaterialApp(home: peca.tela()));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
    });
  }

  testWidgets('peça 02 calcula o IMC', (tester) async {
    await tester.pumpWidget(MaterialApp(home: TelaCalculo()));
    await tester.enterText(find.byType(TextFormField).at(0), "70");
    await tester.enterText(find.byType(TextFormField).at(1), "175");
    await tester.tap(find.text("Calcular"));
    await tester.pump();
    expect(find.text("Peso Normal (22.86)"), findsOneWidget);
  });

  testWidgets('peça 08 adiciona, marca e remove', (tester) async {
    await tester.pumpWidget(MaterialApp(home: ListaTarefas()));
    expect(find.text("Tarefas (2)"), findsOneWidget);

    await tester.enterText(find.byType(TextField), "Nova");
    await tester.tap(find.text("Adicionar"));
    await tester.pump();
    expect(find.text("Tarefas (3)"), findsOneWidget);
    expect(find.text("Feitas: 1 de 3"), findsOneWidget);

    await tester.tap(find.text("Nova"));
    await tester.pump();
    expect(find.text("Feitas: 2 de 3"), findsOneWidget);

    await tester.tap(find.byIcon(Icons.delete).first);
    await tester.pump();
    expect(find.text("Tarefas (2)"), findsOneWidget);
  });

  testWidgets('peça 09 soma o total, filtra e cadastra', (tester) async {
    await tester.pumpWidget(MaterialApp(home: ListaCompras()));
    // 2*25.90 + 8.50 + 3*18.00 = 114.30
    expect(find.textContaining("Total: R\$ 114.30"), findsOneWidget);

    await tester.enterText(find.byType(TextField), "arr");
    await tester.pump();
    expect(find.text("Arroz"), findsOneWidget);
    expect(find.text("Café"), findsNothing);
    await tester.enterText(find.byType(TextField), "");
    await tester.pump();

    await tester.tap(find.byType(FloatingActionButton));
    await tester.pumpAndSettle();
    await tester.enterText(find.widgetWithText(TextField, "Nome"), "Leite");
    await tester.enterText(find.widgetWithText(TextField, "Preço (R\$)"), "5,70");
    await tester.tap(find.text("Salvar"));
    await tester.pumpAndSettle();
    expect(find.text("Leite"), findsOneWidget);
    expect(find.textContaining("Total: R\$ 120.00"), findsOneWidget);
  });

  testWidgets('app CRUD cadastra, edita e exclui', (tester) async {
    await tester.pumpWidget(MaterialApp(home: TelaLista()));
    expect(find.text("Contatos (3)"), findsOneWidget);

    // cadastro com validação
    await tester.tap(find.byType(FloatingActionButton));
    await tester.pumpAndSettle();
    await tester.tap(find.text("Salvar"));
    await tester.pump();
    expect(find.text("Campo obrigatório"), findsNWidgets(2));
    await tester.enterText(find.byType(TextFormField).at(0), "Zeca");
    await tester.enterText(find.byType(TextFormField).at(1), "9999");
    await tester.tap(find.text("Salvar"));
    await tester.pumpAndSettle();
    expect(find.text("Contatos (4)"), findsOneWidget);

    // detalhe -> editar
    await tester.tap(find.text("Zeca"));
    await tester.pumpAndSettle();
    await tester.tap(find.byIcon(Icons.edit));
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextFormField).at(0), "Zeca Silva");
    await tester.tap(find.text("Salvar"));
    await tester.pumpAndSettle();
    expect(find.text("Zeca Silva"), findsWidgets);

    // excluir
    await tester.tap(find.byIcon(Icons.delete));
    await tester.pumpAndSettle();
    await tester.tap(find.text("Sim"));
    await tester.pumpAndSettle();
    expect(find.text("Contatos (3)"), findsOneWidget);
    expect(find.text("Zeca Silva"), findsNothing);
  });
}

void testesDuasTelas() {
  testWidgets('peça 10 envia o nome e volta', (tester) async {
    await tester.pumpWidget(MaterialApp(home: pecas.firstWhere((p) => p.titulo.startsWith("10")).tela()));
    await tester.tap(find.text("Próxima Tela"));
    await tester.pumpAndSettle();
    expect(find.text("Digite o nome"), findsOneWidget);

    await tester.enterText(find.byType(TextField), "Luiz");
    await tester.tap(find.text("Próxima Tela"));
    await tester.pumpAndSettle();
    expect(find.text("Olá, Luiz!"), findsOneWidget);

    await tester.tap(find.text("Voltar"));
    await tester.pumpAndSettle();
    expect(find.text("Primeira Tela"), findsOneWidget);
    expect(find.text("Olá, Luiz!"), findsNothing);
  });
}
